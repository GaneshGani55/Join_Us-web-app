use join_us;


SELECT * FROM users order by created_at;
select * from users order by created_at desc limit 1;

